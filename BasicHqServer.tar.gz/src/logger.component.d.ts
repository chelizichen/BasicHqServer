declare class loggerComponent {
    constructor();
    info(...args: any[]): void;
    data(...args: any[]): void;
    error(...args: any[]): void;
}
export default loggerComponent;
