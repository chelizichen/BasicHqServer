import loggerComponent from "./logger.component";
export declare class CherrioService {
    logger: loggerComponent;
    constructor();
    msg: string;
    greet(): string;
    GetBKHQ(TARGET: string): Promise<unknown>;
}
