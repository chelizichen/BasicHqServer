import { Request, Response, Express, Router } from "express";
import { CherrioService } from "./index.service";
import loggerComponent from "./logger.component";
declare class CherrioController {
    ctx: Express;
    router: Router | undefined;
    logger: loggerComponent;
    CherrioService: CherrioService;
    serverName: string;
    HY_FILE: string;
    constructor(ctx: Express);
    hello(req: Request, res: Response): Promise<void>;
    GetBKHQ(req: Request, res: Response): Promise<void>;
}
export { CherrioController };
