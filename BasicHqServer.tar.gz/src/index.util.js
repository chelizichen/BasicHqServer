"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateRandomCallbackName = generateRandomCallbackName;
exports.replaceTarget = replaceTarget;
exports.getBKHQ = getBKHQ;
exports.getConf = getConf;
var axios_1 = __importDefault(require("axios"));
var lodash_1 = __importDefault(require("lodash"));
function generateRandomCallbackName() {
    var randomPart = Math.floor(Math.random() * 10000000000000000).toString(); // 生成一个 16 位的随机数
    var timestamp = Date.now(); // 获取当前时间戳
    return "jQuery".concat(randomPart, "_").concat(timestamp);
}
function replaceTarget(URL) {
    var PARAMS = "[JSONPCALLBACK]";
    var NAME = generateRandomCallbackName();
    return {
        URL: URL.replace(PARAMS, NAME),
        NAME: NAME,
    };
}
function getBKHQ(TARGET) {
    return new Promise(function (resolve) {
        var T = replaceTarget(TARGET);
        axios_1.default.get(T.URL).then(function (res) {
            var data = res.data;
            var ret = eval(data.replace(T.NAME, ""));
            var diff = lodash_1.default.get(ret, "data.diff", []) || [];
            var charts = lodash_1.default.map(diff, function (item) {
                var _a = [item.f14, item.f3], bkmc = _a[0], jrzf = _a[1];
                return {
                    name: bkmc,
                    value: jrzf,
                };
            });
            var sortChartsData = lodash_1.default.orderBy(charts, "value", "desc");
            resolve(sortChartsData);
        });
    });
}
function getConf(key) {
    try {
        return lodash_1.default.get(JSON.parse(process.env.SGRID_CONFIG), key, "");
    }
    catch (e) {
        console.log("e", e);
        return "";
    }
}
//# sourceMappingURL=index.util.js.map