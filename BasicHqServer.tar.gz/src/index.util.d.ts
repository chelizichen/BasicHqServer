export declare function generateRandomCallbackName(): string;
export declare function replaceTarget(URL: any): {
    URL: any;
    NAME: string;
};
export declare function getBKHQ(TARGET: string): Promise<unknown>;
export declare function getConf(key: string): any;
